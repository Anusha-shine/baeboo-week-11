const User = require('../models/userSchema');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Order = require('../models/orderSchema');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { getFilteredOrders } = require('../helpers/salesReportHelper');

const pageError = async (req, res) => [
  res.render('admin/pageError')
]


const loadLogin = (req, res) => {
  if (req.session.admin) {
    return res.redirect('/admin/dashboard');
  }
  res.render('admin/login', { message: null });
}

const Login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await User.findOne({ email, isAdmin: true });
    if (admin) {
      const passwordMatch = await bcrypt.compare(password, admin.password);
      if (passwordMatch) {
        req.session.admin = true;
        return res.redirect('/admin/dashboard');
      } else {
        return res.redirect('/admin/login');
      }
    }
  } catch (error) {
    console.log("login error", error);
    return res.redirect('/pageError');
  }
}

const loadDashboard = async (req, res) => {
  if (req.session.admin) {
    try {
      res.render('admin/dashboard');
    } catch (error) {
      res.redirect('/pageError');
    }
  }
}
const Logout = async (req, res) => {
  try {
    req.session.destroy(err => {
      if (err) {
        console.log("Error in destroying session", err);
        return res.redirect('/pageError');
      }
      res.redirect('/admin/login');
    });

  } catch (error) {
    console.log("Unexpected error in logout", error);
    return res.redirect('/pageError');

  }
}

const getSalesReport = async (req, res) => {
  const filters = req.query;

  // 1. Paginated Orders
  const { orders, totalOrders, page, limit } = await getFilteredOrders(filters);

  // 2. Match condition (duplicate logic for summary calc)
  const match = {};
  if (filters.filter === 'daily') {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    match.createdAt = { $gte: today };
  } else if (filters.filter === 'weekly') {
    const today = new Date();
    const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
    startOfWeek.setHours(0, 0, 0, 0);
    match.createdAt = { $gte: startOfWeek };
  } else if (filters.filter === 'monthly') {
    const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    match.createdAt = { $gte: startOfMonth };
  }

  if (filters.fromDate && filters.toDate) {
    match.createdAt = {
      $gte: new Date(filters.fromDate),
      $lte: new Date(filters.toDate),
    };
  }

  // 3. Fetch all matched (unpaginated) orders for summary
  const allOrders = await Order.find(match);

  let totalAmount = 0;
  let finalAmount = 0;

  allOrders.forEach(order => {
    totalAmount += order.totalAmount || 0;
    finalAmount += order.finalAmount || 0;
  });
  const totalDiscount = totalAmount - finalAmount;
  const summary = {
    totalOrderCount: allOrders.length,
    totalAmount,
    totalDiscount,
    finalAmount
  };

  const totalPages = Math.ceil(totalOrders / limit);

  res.render('admin/salesReport', {
    orders,
    summary,
    filters,
    pagination: {
      totalPages,
      currentPage: page
    }
  });
};
const downloadSalesReport = async (req, res) => {
  try {
    const { type } = req.params;
    // Reconstruct same filter logic as in getSalesReport (without pagination)
    const filters = req.query;
    const match = {};

    if (filters.filter === 'daily') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      match.createdAt = { $gte: today };
    } else if (filters.filter === 'weekly') {
      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      startOfWeek.setHours(0, 0, 0, 0);
      match.createdAt = { $gte: startOfWeek };
    } else if (filters.filter === 'monthly') {
      const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      match.createdAt = { $gte: startOfMonth };
    }

    if (filters.fromDate && filters.toDate) {
      match.createdAt = {
        $gte: new Date(filters.fromDate),
        $lte: new Date(filters.toDate),
      };
    }

    // Fetch all matching orders (no pagination)
    const orders = await Order.find(match).populate('user');


    // Summary
    const totalOrders = orders.length;
    const totalAmount = orders.reduce((sum, order) => sum + (order.totalAmount || 0), 0);
    const totalFinal = orders.reduce((sum, order) => sum + (order.finalAmount || 0), 0);
    const totalDiscount = totalAmount - totalFinal;

    if (type === 'excel') {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Sales Report');

      // Summary Rows
      worksheet.addRow(['Summary']);
      worksheet.addRow(['Total Orders', totalOrders]);
      worksheet.addRow(['Total Amount', totalAmount.toFixed(2)]);
      worksheet.addRow(['Total Discount', totalDiscount.toFixed(2)]);
      worksheet.addRow(['Final Amount', totalFinal.toFixed(2)]);
      worksheet.addRow([]); // empty row for spacing

      worksheet.columns = [
        { header: 'Date', key: 'date', width: 15 },
        { header: 'Order ID', key: 'orderId', width: 25 },
        { header: 'Customer', key: 'customer', width: 20 },
        { header: 'Total', key: 'total', width: 10 },
        { header: 'Discount', key: 'discount', width: 10 },
        { header: 'Final', key: 'final', width: 10 },
        { header: 'Payment Method', key: 'payment', width: 15 },
      ];

      orders.forEach(order => {
        worksheet.addRow({
          date: order.createdAt.toLocaleDateString(),
          orderId: order._id,
          customer: order.user?.name || 'Unknown',
          total: order.totalAmount?.toFixed(2) || 0,
          discount: ((order.totalAmount - order.finalAmount) || 0).toFixed(2),
          final: order.finalAmount?.toFixed(2) || 0,
          payment: order.paymentMethod,
        });
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=sales-report.xlsx');
      await workbook.xlsx.write(res); // Await ensures stream completes before ending response
      res.end();

    } else if (type === 'pdf') {
      const doc = new PDFDocument({ margin: 40, size: 'A4' });
      const tableTop = 180;
      const rowHeight = 20;

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename=sales-report.pdf');
      doc.pipe(res);

      // Title
      doc.fontSize(20).font('Helvetica-Bold').text('Sales Report', { align: 'center' });
      doc.moveDown();

      // Summary
      doc.fontSize(12).font('Helvetica-Bold').text('Summary:', 40);
      doc.font('Helvetica').text(`Total Orders: ${totalOrders}`);
      doc.text(`Total Amount: ₹${totalAmount.toFixed(2)}`);
      doc.text(`Total Discount: ₹${totalDiscount.toFixed(2)}`);
      doc.text(`Final Amount: ₹${totalFinal.toFixed(2)}`);
      doc.moveDown();

      // Table Headers
      doc.rect(40, tableTop, 520, rowHeight).fill('#eeeeee');
      doc.fillColor('#000').fontSize(12).font('Helvetica-Bold');

      const headers = ['Date', 'Order ID', 'Customer', 'Total', 'Discount', 'Final', 'Payment'];
      const columnWidths = [70, 80, 100, 60, 60, 60, 90];
      const columnStarts = columnWidths.reduce((acc, width, i) => {
        acc.push(i === 0 ? 40 : acc[i - 1] + columnWidths[i - 1]);
        return acc;
      }, []);

      headers.forEach((header, i) => {
        doc.text(header, columnStarts[i] + 2, tableTop + 5, { width: columnWidths[i] - 4, align: 'left' });
      });

      // Table Rows
      let y = tableTop + rowHeight;
      doc.font('Helvetica').fontSize(10);

      for (let order of orders) {
        if (y > 750) {
          doc.addPage();
          y = 60;

          // Repeat table headers on new page
          doc.rect(40, y, 520, rowHeight).fill('#eeeeee');
          headers.forEach((header, i) => {
            doc.fillColor('#000').font('Helvetica-Bold').fontSize(12);
            doc.text(header, columnStarts[i] + 2, y + 5, { width: columnWidths[i] - 4, align: 'left' });
          });
          y += rowHeight;
          doc.font('Helvetica').fontSize(10);
        }

        const rowData = [
          order.createdAt.toLocaleDateString(),
          order._id.toString().slice(-6),
          order.user?.name || 'Unknown',
          `₹${(order.totalAmount || 0).toFixed(2)}`,
          `₹${((order.totalAmount - order.finalAmount) || 0).toFixed(2)}`,
          `₹${(order.finalAmount || 0).toFixed(2)}`,
          order.paymentMethod || 'N/A',
        ];

        rowData.forEach((text, i) => {
          doc.text(text, columnStarts[i] + 2, y + 5, { width: columnWidths[i] - 4, align: 'left' });
        });

        y += rowHeight;
      }

      doc.end();

    } else {
      res.status(400).send('Invalid format requested.');
    }
  } catch (error) {
    console.error('Error in downloadSalesReport:', error);
    res.status(500).send('Internal Server Error');
  }
};



module.exports = {
  loadLogin, Login, loadDashboard, pageError, Logout, getSalesReport,
  downloadSalesReport
};